const Post=require('../models/post');

exports.createPost=(req,res,next)=>{
    const url=req.protocol+'://'+req.get("host");
    const post= new Post({
      title:req.body.title,
      content:req.body.content,
      imagePath:url+"/images/" + req.file.filename,
      creator: req.userData.userId
    });
   
    // const post=req.body;
    // console.log(post);
    post.save().then(createPost=>{
      res.status(201).json({
        message:'Post added Successfully!',postId:createPost._id,
        post:{
          ...createPost,
          id:createPost._id
          // title:createPost.title,
          // content:createPost.content,
          // imagePath:create.imagePath
        }
      });
    })
      .catch(error =>{
        res.status(500).json({
          message:" Creating a post failed"
        })
      })
  }
  exports.updatePost=(req,res,next)=>{
    let imagePath= req.body.imagePath;
     if(req.file){
     const url=req.protocol+'://'+req.get("host");
     imagePath= url+"/images/" + req.file.filename
   
    }
     console.log(req.file);
     const post=new Post({
       _id:req.body.id,
       title:req.body.title,
       imagePath:imagePath,
       content:req.body.content,
       creator: req.userData.userId
     })
     Post.updateOne({_id: req.params.id,creator:req.userData.userId},post).then(result=>{
       console.log(result);
       if (result.n > 0){
         res.status(200).json({message:"Update Successfull !"});
   
       }
       else{
       res.status(400).json({message:"Not Authorized !"});
   
       }
     })
     .catch(error=>{
       res.status(500).json({
         message:"Couldn't update post!"
       })
     })
   }
   exports.getPosts=(req,res,next)=>{
    const pageSize= +req.query.pagesize;
    console.log(req.query);
    const currentPage= +req.query.page;
    const postQuery= Post.find();
    let fetchedPosts;
    if(pageSize && currentPage){
     postQuery
     .skip(pageSize * (currentPage - 1))
     .limit(pageSize);
    }
   //  res.send('Hello from express!');
   // const posts=[
   //   {id:'m1',title:'First server-side post',content:'this is coming from server'},
   //   {id:'m2',title:'second server-side post',content:'this is coming from server!'},
   //   {id:'m3',title:'third server-side post',content:'this is coming from server!!'}
   
   // oNNfGEBor2OQByUW
   // oNNfGEBor2OQByUW
   
   postQuery.then(documents =>{
     fetchedPosts=documents;
     return Post.count();
   // console.log(documents);
   }).then(
     count=>{
       res.status(200).json({message:'Posts fetched succesfully!',
       posts:fetchedPosts,maxPosts:count
       });
     }
   ).catch(error=>{
     res.status(500).json({
       message: "Fetching posts failed!"
     })
   });
   
   }
   exports.getPost=(req,res,next)=>{
    Post.findById(req.params.id).then(post=>{
      if(post){
          res.status(200).json(post)
      }
      else(
        res.status(404).json({message: 'Post not Found'})
      )
    })
    .catch(error=>{
      res.status(500).json({
        message: "Fetching posts failed!"
      })
    })
  }
  exports.deletePost=(req,res,next)=>{
    // console.log(req.params.id);
    Post.deleteOne({_id:req.params.id,creator: req.userData.userId}).then(result =>{
      console.log(result);
      if (result.n > 0){
        res.status(200).json({message:"Deletion Successfull !"});
    
      }
      else{
      res.status(400).json({message:"Not Authorized !"});
    
      }
    }).catch(error=>{
      res.status(500).json({
        message: "Fetching posts failed!"
      })
    });
  }