// typescript feature: like a class which indicates hoe the objct looks
 export interface Post{
 
  id?:string | null | any;
  title?:string;
  content?:string;
imagePath:string |any;
creator: string | null;
}
